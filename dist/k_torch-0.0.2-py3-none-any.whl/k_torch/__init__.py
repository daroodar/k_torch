# K torch init file
name = 'k_torch'